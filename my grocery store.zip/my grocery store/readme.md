open this folder on any ide. After that you need to set up virtual environment if it is not setup. Later after setting it up you can run file by typing python main.py
then the application will run on local host , on following the link you land on index page which is main page. you will have two options signin and signup.
Later after choosing what you want , you can check the functionalities of user(customer) and admin(store manager).
