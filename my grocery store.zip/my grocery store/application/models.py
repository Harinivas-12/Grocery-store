from .database import db

class Product(db.Model):
    __tablename__ = 'product'
    id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    category = db.Column(db.String ,db.ForeignKey('category.category_name'))
    name = db.Column(db.String)
    units = db.Column(db.Integer)
    price = db.Column(db.Float,unique = False)
    stock = db.Column(db.Integer)

class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer,primary_key = True ,autoincrement = True)
    email = db.Column(db.String)
    password = db.Column(db.String)
    username = db.Column(db.String,primary_key = True)
    role = db.Column(db.String, default = 'USER')

class Category(db.Model):
    __tablename__ = 'category'
    id = db.Column(db.Integer,autoincrement  =True,primary_key = True)
    category_name = db.Column(db.String)


    