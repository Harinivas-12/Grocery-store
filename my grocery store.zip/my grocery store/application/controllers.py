import flask
from flask import Flask, request, render_template, redirect , url_for
from application.models import User, Product, Category
from .database import db
from datetime import datetime as dt
import json
from flask import current_app as app
from io import BytesIO
from werkzeug.utils import secure_filename
import os


@app.route("/", methods=['GET','POST'])
def home1():
    return render_template('index.html')

@app.route("/manager", methods = ["GET" , "POST"])
def manager():
    if request.method == "GET":
        product = Product.query.all()
    return render_template("index_m.html",products = product)

@app.route("/signin", methods = ["GET","POST"])
def signin():
    return render_template("signin.html")

@app.route("/signup", methods = ["GET","POST"])
def signup():
    return render_template("signup.html")

@app.route("/logout",methods = ["GET","POST"])
def logout():
    return redirect(url_for("home1"))

@app.route("/user",methods = ["GET","POST"])
def user():
    if request.method=="GET":
        ret = Product.query.all()
        return render_template("index_home.html",products = ret)
    
@app.route("/updated",methods = ["GET","POST"])
def updated():
    if request.method == 'GET':
        up = Product.query.all()
        return  render_template("index_m.html",products = up)
    
@app.route("/checkout",methods = ["GET","POST"])
def checkout():
    return render_template("checkout.html")

@app.route("/edit_product", methods=["POST"])
def edit_product():
    product_id = request.form.get("id")  # Assuming you get the product ID from a form field
    product = Product.query.get(product_id)

    if product:
        return render_template("update_product.html", product=product)
    else:
        return redirect(url_for("manager"))  # Redirect to a product list or error page if product is not found

#this for enrolling or signing up for grocery store
@app.route("/enroll",methods = ["GET","POST"])
def enroll():
    if request.method == 'POST':
        fname = request.form['name']
        email = request.form['email']
        password = request.form['password']

        members = User.query.filter_by(email=email).first()
        if members is None:
            user_details = User(username=fname, email=email, password=password)
            db.session.add(user_details)
            db.session.commit()

            mem = User.query.filter_by(email=email).first()
            u_id = mem.id
            return render_template("signin.html")

        else:
            return redirect(url_for("login"))

    else:
        return render_template("signup.html")
#this is for logging customer based on  his role , it could be admin or user
@app.route("/login" , methods = ["GET","POST"])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        members = User.query.filter_by(email = email).first()
        if members:
            if members.password == password and members.role =="ADMIN" :
                return redirect(url_for('manager'))
            elif members.role == "USER":
                return redirect(url_for("user"))
        else:
            return render_template("index_admin.html")

    else:
        return render_template("signin.html")
    
#now adding products 
@app.route('/add_product', methods=['POST'])
def add_product():
    if request.method == 'POST':
        category = request.form['category']
        name = request.form['name']
        units = request.form['units']
        price = float(request.form['price'])
        stock = int(request.form['stock'])

        # Create a new product and add it to the database
        products = Product(category=category, name=name, units=units, price=price, stock=stock)
        db.session.add(products)
        db.session.commit()
        products = Product.query.all()

        return render_template('index_m.html', products=products)

    return redirect(url_for('manager')) 
@app.route('/delete_by_category_and_name', methods=['POST'])
def delete_by_category_and_name():
    if request.method == 'POST':
        category = request.form.get('Category')  # Get category from the form
        name = request.form.get('Name')          # Get name from the form

        # Find the product with the specified category and name
        product_to_delete = Product.query.filter_by(category=category, name=name).first()

        if product_to_delete:
            # Delete the product (including all associated data) from the database
            db.session.delete(product_to_delete)
            db.session.commit()
    return redirect(url_for('updated'))       
        
@app.route('/delete_product', methods=['POST'])
def delete_product():
    if request.method == 'POST':
        product_id = request.form['id']
        
        # Retrieve the product from the database based on the product_id
        product = Product.query.get(product_id)

        # Check if the product exists
        if product:
            # Delete the product from the database
            db.session.delete(product)
            db.session.commit()

    # Handle any errors or invalid requests
    return redirect(url_for('updated'))
#updating products from manager side
@app.route('/update_product', methods=['GET', 'POST'])
def update_product():
    if request.method == 'POST':
        # Handle the form submission and update the product in the database
        try:
            product_id = int(request.form['id'])
            updated_units = int(request.form['units'])
            updated_price = float(request.form['price'])
            updated_stock = int(request.form['stock'])

            # Update the product in the database
            product = Product.query.get(product_id)
            if product:
                product.units = updated_units
                product.price = updated_price
                product.stock = updated_stock
                db.session.commit()

                # Fetch the updated product from the database
                updated_product = Product.query.get(product_id)

                # Render the "update_product.html" template with the updated product
                return redirect(url_for("updated"))
            else:
                return "Product not found"
        except Exception as e:
            db.session.rollback()  # Rollback changes on error
            return f"Error updating product: {str(e)}"











    


        






